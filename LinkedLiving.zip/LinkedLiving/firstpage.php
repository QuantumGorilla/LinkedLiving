<!DOCTYPE html>
<html>
<head>
	<title>LinkedLiving</title>
    <meta charset="utf-8">
    <link rel="stylesheet" a href="css\estiloPrincipal.css">
</head>
<body>
    <img src="imagenes/Logo2.png"/>
</body>
</html>
