<!DOCTYPE html>
<html>
<head>
	<title>LinkedLiving</title>
    <meta charset="utf-8">
    <link rel="stylesheet" a href="css\estiloDetalles.css">
</head>
<body>
    <center align=RIGHT>
        <form id="botones" method="post" action="./principal.php">
			<input type="submit" type="submit" value="Cerrar sesión" align=LEFT/>
    </center>
    <center>
        <img src="./imagenes/Logo3.png" /><br>
    </center>
    <img src="./posts/publi5.jpg" style="float: right"/>
     <img src="./posts/publi4.jpg" style="float: left" />
    <section>
        <h2><a href="usuario1.php">Carlos27</a></h2>
        <img src="./posts/casa1.jpg" /> 
        
        <h3>
            LAS ACACIAS
        </h3>
        <h4>
        
        CASAS<br>    
        Desde: $ 120.000.000<br>
        Pensiones desde: $550.000<br>
        Ciudad: Soledad<br>
        Área construida: desde 32 m2 hasta 64 m2<br>
        </h4>
        
    </section>
        <section>
            <h2><a href="usuario2.php">LaNorte Casas</a></h2>
            <img src="./posts/casa2.jpg" width="480" height="320"/>
            <h3>
            ACUARELA DEL RÍO
        </h3>
        <h4>
            
        APARTAMENTOS<br>
        Desde: $ 265.700.000<br>
        Pensiones desde: $600.000<br>
        Ciudad: Barranquilla<br>
        Área construida: desde 80 m2 hasta 112 m2<br>
        </h4>
        </section>
        <section>
            <h2><a href="usuario3.php">CasasBakanas</a></h2>
            <img src="./posts/casa3.jpg" width="480" height="320"/>
            <h3>
            PARK 68

        </h3>
        <h4>
            
        APARTAMENTOS<br>
        Desde: $ 302.958.560<br>
        Pensiones desde: $650.000<br>
        Ciudad: Barranquilla<br>
        Área construida: desde 56 m2 hasta 76 m2<br>
        </h4>
        </section>
        <section>
            <h2><a href="usuario4.php">Inmobiliarias el Peter</a></h2>
            <img src="./posts/casa4.jpg" width="480" height="320"/>
            <h3>
            UB. ALTOS DE PARQUE Barranquilla
        </h3>
        <h4>
            
        CASAS<br>
        Desde: $950.000.000<br>
        Pensiones desde: $800.000<br>
        Ciudad: Barranquilla<br>
        Área construida: 245.0 m2<br>
        Hab: 3<br>
        Baños: 4<br>
        Garajes: 2<br>
        </h4>
        </section>
        <section>
            <h2><a href="usuario5.php">11-11</a></h2>
            <img src="./posts/casa5.jpg" width="480" height="320"/>
            <h3>
            LOS NOGALES
        </h3>
        <h4>
        
        CASAS<br>   
        Desde: $560.000.000<br>
        Pensiones desde: $700.000<br>
        Ciudad: Soledad<br>
        Área construida: 300.0 m2<br>
        Hab: 4<br>
        Baños: 3 <br>
        Garajes: 2<br>
        </h4>
        </section>
        <section>
            <h2><a href="usuario1.php">Carlos27</a></h2>
            <img src="./posts/casa6.jpg" width="480" height="320"/>
            <h3>
            OLAYA
        </h3>
        <h4>
            
        APARTAMENTOS<br>
        Desde: $299.000.000<br>
        Pensiones desde: $650.000<br>
        Ciudad: Barranquilla<br>
        Área construida: 86.0 m2<br>
        Hab: 3<br>
        Baños: 3 <br>
        Garajes: 1<br>
        </h4>
        </section>
</body>
</html>
