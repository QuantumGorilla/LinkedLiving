<!DOCTYPE html>
<html>
<head>
	<title>LinkedLiving</title> 
    <meta charset="utf-8">
    <link rel="stylesheet" a href="css\estiloDetalles2.css">
    <style>
    div {
      border: black 3px solid;
      overflow: auto;
    }

    img {
      float: left;
    }
  </style>
</head>
<body>
    <center align=RIGHT>
        <form id="botones" method="post" action="./firstpage.php">
      <input type="submit" type="submit" value="Regresar" align=LEFT/>
    </center>
    <img src="imagenes/Logo2.png"/><br><br><br><br>
    <section>
        <h2> <p style="color:#0B0B61;"> LaNorteC</p></h2>
        <div>
        <p><img src="imagenes/Avatar.png" align="float: left" width="140" height="140" />ID: 02</p>
         <p>Nombre: LaNorte Casas</p>
         <p>Teléfono: 3222222</p>
         <p>Correo elextrónico: lanorte@uninorte.edu.co</p>
        </div>
        <!--<p><img src="imagenes/4e.png" width="140" height="140"></p>-->
        <p>Calificación:</p>
        <p><img src="./posts/5e.png" width="140" height="27"></p><br>
        <br>
        <p>Posts de ventas:</p>
        <h3>ACUARELA DEL RÍO</h3>
        
    </section>
        
        
</body>
</html>
