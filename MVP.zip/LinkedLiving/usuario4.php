<!DOCTYPE html>
<html>
<head>
	<title>LinkedLiving</title> 
    <meta charset="utf-8">
    <link rel="stylesheet" a href="css\estiloDetalles2.css">
    <style>
    div {
      border: black 3px solid;
      overflow: auto;
    }

    img {
      float: left;
    }
  </style>
</head>
<body>
    <center align=RIGHT>
        <form id="botones" method="post" action="./firstpage.php">
      <input type="submit" type="submit" value="Regresar" align=LEFT/>
    </center>
    <img src="imagenes/Logo2.png"/><br><br><br><br>
    <section>
        <h2> <p style="color:#0B0B61;"> El Peter</p></h2>
        <div>
        <p><img src="imagenes/Avatar.png" align="float: left" width="140" height="140" />ID: 04</p>
         <p>Nombre: Peter Parker</p>
         <p>Teléfono: 3666776521</p>
         <p>Correo elextrónico: elpeter@gmail.com</p>
        </div>
        <!--<p><img src="imagenes/4e.png" width="140" height="140"></p>-->
        <p>Calificación:</p>
        <p><img src="./posts/2e.png" width="140" height="27"></p><br>
        <br>
        <p>Posts de ventas:</p>
        <h3>UB. ALTOS DE PARQUE Barranquilla</h3>
    </section>
        
        
</body>
</html>
